#ifndef __ALL_GUI__H__
#define __ALL_GUI__H__
#include "lvgl.h"
void All_Gui(void);


#endif  //!__ALL_GUI__H__

