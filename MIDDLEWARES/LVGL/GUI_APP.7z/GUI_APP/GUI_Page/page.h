#ifndef __PAGE__H__
#define __PAGE__H__
#include "page0.h"
#include "page1.h"
#include "page2.h"
#include "page3.h"
#include "page3_1.h"
#include "page4.h"
int prepage;

#endif //!__PAGE__H__