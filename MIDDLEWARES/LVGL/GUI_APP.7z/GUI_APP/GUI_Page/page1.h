#ifndef __PAGE1__H__
#define __PAGE1__H__

#include "lvgl.h"
#include "gui_manage.h"
#include "mem_manage.h"


void page1_init(lv_obj_t *root);




#endif  //!__PAGE1__H__