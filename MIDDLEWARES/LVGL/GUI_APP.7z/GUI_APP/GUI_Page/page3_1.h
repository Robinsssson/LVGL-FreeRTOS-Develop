#ifndef __PAGE3_1__H__
#define __PAGE3_1__H__

#include "lvgl.h"
#include "gui_manage.h"
#include "mem_manage.h"


void page3_1_init(lv_obj_t *root);





#endif  //!__PAGE3__H__