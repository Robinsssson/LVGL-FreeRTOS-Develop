#ifndef __PAGE4__H__
#define __PAGE4__H__
#include "lvgl.h"
#include "gui_manage.h"

void page4_init(lv_obj_t *root);

#endif  //!__PAGE4__H__