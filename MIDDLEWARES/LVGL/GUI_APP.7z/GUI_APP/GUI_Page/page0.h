#ifndef __PAGE0__H__
#define __PAGE0__H__

#include "lvgl.h"
#include "gui_manage.h"
#include "mem_manage.h"

void page0_init(lv_obj_t *root);





#endif  //!__PAGE0__H__