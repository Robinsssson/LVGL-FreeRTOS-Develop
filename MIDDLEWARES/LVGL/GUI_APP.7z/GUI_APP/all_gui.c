#include "all_gui.h"
#include "GUI_Manage/gui_manage.h"
#include "page_main.h"
void All_Gui(void)
{
    // page_container_init();
    GUI_Init();
}

