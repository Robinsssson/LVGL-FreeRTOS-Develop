#include "gui_manage.h"

#if 1



#endif