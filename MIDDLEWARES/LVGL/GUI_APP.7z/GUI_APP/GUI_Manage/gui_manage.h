#ifndef __GUI_MANAGE__H__
#define __GUI_MANAGE__H__
#include "lvgl.h"
#if 1

#endif
#endif //!__GUI_MANAGE__H__
